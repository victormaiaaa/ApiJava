package com.firstproject.ApiVictor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiVictorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiVictorApplication.class, args);
	}

}
