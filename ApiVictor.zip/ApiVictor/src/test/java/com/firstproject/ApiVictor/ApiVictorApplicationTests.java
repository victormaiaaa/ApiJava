package com.firstproject.ApiVictor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiVictorApplicationTests {

	@Test
	void contextLoads() {
	}

}
